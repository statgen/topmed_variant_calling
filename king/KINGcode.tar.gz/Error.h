#ifndef _ERROR_H_
#define _ERROR_H_

// #ifdef __cplusplus
// extern "C" {
// #endif

void error(const char * msg, ...);
void warning(const char * msg, ...);
void numerror(const char * msg, ...);

// #ifdef __cplusplus
//   };
// #endif


#endif
